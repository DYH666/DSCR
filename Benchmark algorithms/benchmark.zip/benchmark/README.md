# DSCR
A public Dataset for Ship Classification in Remote sensing images.

##Dataset
Please download the dataset from 

## Benchmark algorithms Install
* Install PyTorch=0.4.0 
*         python=3.6              |


